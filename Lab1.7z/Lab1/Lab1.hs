{- Lab 1
   Authors: Adam Delin, 
   Lab group: 52
 -}
---------------------------------------------
import Graphics.Win32.Key (kLF_REORDER)
power :: Integer -> Integer -> Integer
power n k
   | k < 0 = error "power: negative argument"
power n 0  = 1
power n k  = n * power n (k-1)

-- A -------------------------
-- stepsPower n k gives the number of steps that
-- power n k takes to compute

stepsPower :: Integer -> Integer -> Integer
stepsPower n k = k + 1



-- B -------------------------
-- power1

power1 :: Int -> Int -> [Int] 
power1 n k
   |k > 0 = n : power1 n (k-1)
   |otherwise  = []

-- C -------------------------
-- power2

power2 :: Integer -> Integer -> Integer  
power2 n k
   | k < 0 = error "power: negative argument"
power2 n k 
   |k == 0 = 1
   |even k = (n*n)*power2 n (div k 2)
   |odd k = n*power2 n (k-1)

-- D -------------------------
{- 

<Describe your test cases here>

 -}

-- comparePower1
comparePower1 = undefined

-- comparePower2
comparePower2 = undefined

-- Test functions: 

